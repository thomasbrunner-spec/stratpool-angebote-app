# Projekt: stratpool-app-template (RENAME ME)

> Diese Datei ergänzt die globale `~/.claude/CLAUDE.md`.
> Wenn du dieses Template verwendet hast, **passe diese Datei** auf deine App an.

## Über dieses Projekt

**Name:** [APP-NAME] — z.B. "Angebote-App"
**Zweck:** [In einem Satz: was tut diese App?]
**Repo:** `thomasbrunner-spec/stratpool-[app-name]`
**Subdomain:** `[app-name].stratpool.pro`
**Status:** [In Entwicklung | Live | Deprecated]

## Architektur

Standard-Monorepo aus dem `stratpool-app-template`. Backend in `backend/` (FastAPI),
Frontend in `frontend/` (Next.js 15). Beide werden zusammen via Docker Compose
deployt.

## Was bei diesem Projekt anders ist

[Wenn nichts vom Standard abweicht: "Folgt dem Standard-Stack aus dem Template
und der globalen CLAUDE.md."]

## Wichtige Pfade

```
backend/app/main.py             # FastAPI-Entry
backend/app/services/           # Business-Logic (LLM, Embeddings, Auth)
backend/app/routes/             # API-Endpoints
frontend/app/                   # Next.js Pages
frontend/components/            # React-Komponenten
frontend/lib/api.ts             # Backend-API-Helper mit Auth
docker-compose.yml              # Coolify-Deployment
```

## Häufige Aufgaben

### Lokale Entwicklung
```bash
docker compose up --build
# oder native:
cd backend && uv sync && uv run uvicorn app.main:app --reload
cd frontend && pnpm install && pnpm dev
```

### Tests
```bash
cd backend && uv run pytest
cd frontend && pnpm typecheck
```

### Datenbank-Migration
```bash
cd backend && uv run alembic revision -m "describe change"
# Then edit the generated file in alembic/versions/, then:
uv run alembic upgrade head
```

### Release
- Push auf `main` mit Conventional Commit → Release Please erstellt PR
- Merge des PRs → automatischer Tag + Release
- Coolify watcht das Repo und deployt automatisch

## Anmerkungen für Claude Code

- **Backend nutzt async überall** (FastAPI + SQLAlchemy 2.0 async)
- **Anthropic-Aufrufe** über `app.services.llm.simple_completion()` oder direkt mit
  `get_anthropic_client()` für komplexere Calls
- **Embeddings** über `app.services.embeddings.embed_text()` (Voyage)
- **Auth** über die `CurrentUser`-Dependency in jedem Route, der Auth braucht:
  ```python
  from app.services.auth import CurrentUser

  @router.get("/protected")
  async def protected(user: CurrentUser):
      return {"user_id": user.id}
  ```
- **Frontend → Backend**: Immer `lib/api.ts` benutzen (hängt automatisch JWT an)
- **Niemals** `private: true` in `package.json` der App setzen — sonst kann das
  Frontend-Image nicht bauen
- **Niemals** `pnpm version` doppelt definieren (siehe Sub-Output B Lehren)

## TODOs für neue App

- [ ] `name`-Felder in `package.json` und `pyproject.toml` anpassen
- [ ] `COMPOSE_PROJECT_NAME` in `.env` auf App-Namen setzen
- [ ] `frontend/app/layout.tsx` Metadata aktualisieren
- [ ] DNS A-Record für Subdomain in Domain-Provider setzen
- [ ] Coolify-App anlegen und Env-Variablen setzen
- [ ] Diese CLAUDE.md aktualisieren mit App-spezifischem Kontext
